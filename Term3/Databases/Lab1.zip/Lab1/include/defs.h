#ifndef LAB1_DEFS_H
#define LAB1_DEFS_H

#define CS_FL "../data/caffe_shops.fl"
#define CS_IND "../data/caffe_shops.ind"
#define COM_FL "../data/comments.fl"

#define STR_SIZE 20
#define TEXT_SIZE 255

#endif //LAB1_DEFS_H
