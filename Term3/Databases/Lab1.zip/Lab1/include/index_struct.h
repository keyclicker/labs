#ifndef LAB1_INDEX_STRUCT_H
#define LAB1_INDEX_STRUCT_H
#include <stddef.h>

struct index_struct {
  size_t key;
  size_t pos;
};

#endif //LAB1_INDEX_STRUCT_H
